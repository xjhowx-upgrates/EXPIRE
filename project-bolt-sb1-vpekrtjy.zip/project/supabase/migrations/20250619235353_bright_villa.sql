/*
  # EXPIRE - Schema Completo Final
  # Plataforma de jogos baseada em tempo - Versão de Produção

  1. Tabelas Principais
    - `profiles` - Perfis dos usuários com minutos disponíveis
    - `games` - Catálogo de jogos disponíveis
    - `game_scores` - Pontuações dos jogadores
    - `game_sessions` - Sessões de jogo
    - `leaderboard` - Classificação global
    - `achievements` - Sistema de conquistas
    - `user_achievements` - Progresso das conquistas dos usuários

  2. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas específicas para cada operação
    - Triggers para atualizações automáticas

  3. Funcionalidades
    - Sistema de tempo automático
    - Ranking em tempo real
    - Conquistas progressivas
    - Histórico completo de jogos
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing tables if they exist (for clean setup)
DROP TABLE IF EXISTS user_achievements CASCADE;
DROP TABLE IF EXISTS achievements CASCADE;
DROP TABLE IF EXISTS leaderboard CASCADE;
DROP TABLE IF EXISTS game_sessions CASCADE;
DROP TABLE IF EXISTS game_scores CASCADE;
DROP TABLE IF EXISTS games CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  available_minutes integer DEFAULT 120 NOT NULL,
  total_score integer DEFAULT 0 NOT NULL,
  games_played integer DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create games table
CREATE TABLE games (
  id serial PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  image_url text,
  category text NOT NULL DEFAULT 'slots',
  provider text DEFAULT 'EXPIRE Games',
  rtp decimal(5,2) DEFAULT 96.5,
  volatility text DEFAULT 'medium' CHECK (volatility IN ('low', 'medium', 'high')),
  min_bet integer DEFAULT 1,
  max_bet integer DEFAULT 1000,
  minutes_cost integer DEFAULT 5 NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create game_scores table
CREATE TABLE game_scores (
  id serial PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  game_id integer REFERENCES games(id) ON DELETE CASCADE NOT NULL,
  score integer NOT NULL DEFAULT 0,
  minutes_spent integer NOT NULL DEFAULT 0,
  session_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create game_sessions table
CREATE TABLE game_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  game_type text NOT NULL,
  start_time timestamptz DEFAULT now(),
  end_time timestamptz,
  coins_spent integer DEFAULT 0,
  coins_won integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create leaderboard table
CREATE TABLE leaderboard (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  username text,
  score integer DEFAULT 0,
  rank integer,
  updated_at timestamptz DEFAULT now()
);

-- Create achievements table
CREATE TABLE achievements (
  id serial PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  icon text DEFAULT '🏆',
  rarity text DEFAULT 'common' CHECK (rarity IN ('common', 'rare', 'epic', 'legendary')),
  points integer DEFAULT 100 NOT NULL,
  condition_type text NOT NULL,
  condition_value integer NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create user_achievements table
CREATE TABLE user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  achievement_id integer REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  progress integer DEFAULT 0 NOT NULL,
  is_unlocked boolean DEFAULT false NOT NULL,
  unlocked_at timestamptz,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, achievement_id)
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE leaderboard ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id);

-- RLS Policies for games (public read)
CREATE POLICY "Anyone can read games" ON games
  FOR SELECT TO public
  USING (true);

-- RLS Policies for game_scores
CREATE POLICY "Authenticated users can read all scores" ON game_scores
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own scores" ON game_scores
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own scores" ON game_scores
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for game_sessions
CREATE POLICY "Users can view their own game sessions" ON game_sessions
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own game sessions" ON game_sessions
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own game sessions" ON game_sessions
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for leaderboard
CREATE POLICY "Anyone can view leaderboard" ON leaderboard
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE POLICY "Users can insert their own leaderboard entry" ON leaderboard
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own leaderboard entry" ON leaderboard
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for achievements (public read)
CREATE POLICY "Anyone can view achievements" ON achievements
  FOR SELECT TO public
  USING (is_active = true);

-- RLS Policies for user_achievements
CREATE POLICY "Users can view their own achievements" ON user_achievements
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own achievements" ON user_achievements
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own achievements" ON user_achievements
  FOR UPDATE TO authenticated
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_profiles_available_minutes ON profiles(available_minutes);
CREATE INDEX idx_game_scores_user_id ON game_scores(user_id);
CREATE INDEX idx_game_scores_game_id ON game_scores(game_id);
CREATE INDEX idx_game_scores_score ON game_scores(score DESC);
CREATE INDEX idx_user_achievements_user_id ON user_achievements(user_id);

-- Insert default games
INSERT INTO games (name, slug, description, category, provider, rtp, volatility, minutes_cost, image_url) VALUES
('Fortune Tiger', 'fortune-tiger', 'Junte-se ao poderoso tigre em uma jornada para a riqueza neste jogo de caça-níqueis com tema asiático.', 'slots', 'PG Soft', 96.8, 'high', 5, 'https://images.pexels.com/photos/792381/pexels-photo-792381.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Crash', 'crash', 'Veja o multiplicador subir e saque antes que ele caia neste emocionante jogo de risco e recompensa.', 'crash', 'EXPIRE Games', 97.3, 'high', 3, 'https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Roleta Europeia', 'roulette', 'Experimente o clássico jogo de cassino com múltiplas opções de apostas e estratégias.', 'table', 'EXPIRE Games', 97.3, 'medium', 4, 'https://images.pexels.com/photos/1871508/pexels-photo-1871508.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Sweet Bonanza', 'sweet-bonanza', 'Delicie-se neste caça-níqueis com tema de doces, com vitórias em cascata e giros grátis multiplicadores.', 'slots', 'Pragmatic Play', 96.5, 'high', 5, 'https://images.pexels.com/photos/1028714/pexels-photo-1028714.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Mines', 'mines', 'Limpe o campo sem atingir nenhuma mina neste emocionante jogo de sorte.', 'dice', 'EXPIRE Games', 97.0, 'high', 4, 'https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg?auto=compress&cs=tinysrgb&w=400'),
('Blackjack', 'blackjack', 'Vença o dealer com uma mão melhor neste clássico jogo de cartas de habilidade e sorte.', 'card', 'EXPIRE Games', 99.5, 'low', 6, 'https://images.pexels.com/photos/1871508/pexels-photo-1871508.jpeg?auto=compress&cs=tinysrgb&w=400');

-- Insert default achievements
INSERT INTO achievements (title, description, icon, rarity, points, condition_type, condition_value) VALUES
('Primeiro Passo', 'Jogue seu primeiro jogo', '🎯', 'common', 50, 'games_played', 1),
('Viciado em Jogos', 'Jogue 10 jogos diferentes', '🎮', 'rare', 200, 'games_played', 10),
('Pontuação Alta', 'Alcance 1000 pontos em um único jogo', '⭐', 'epic', 500, 'single_score', 1000),
('Mestre dos Slots', 'Jogue slots 50 vezes', '👑', 'legendary', 1000, 'category_plays', 50),
('Crash Survivor', 'Saque antes do crash 25 vezes', '🚀', 'epic', 300, 'crash_wins', 25),
('Jogador Dedicado', 'Jogue por 7 dias consecutivos', '📅', 'rare', 400, 'consecutive_days', 7),
('Milionário', 'Acumule 10.000 pontos totais', '💰', 'legendary', 2000, 'total_score', 10000),
('Speedrunner', 'Complete 5 jogos em menos de 1 hora', '⚡', 'epic', 600, 'speed_games', 5);

-- Function to update leaderboard ranks
CREATE OR REPLACE FUNCTION update_leaderboard_ranks()
RETURNS TRIGGER AS $$
BEGIN
  WITH ranked_users AS (
    SELECT user_id, ROW_NUMBER() OVER (ORDER BY score DESC) as new_rank
    FROM leaderboard
  )
  UPDATE leaderboard 
  SET rank = ranked_users.new_rank
  FROM ranked_users
  WHERE leaderboard.user_id = ranked_users.user_id;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for leaderboard ranking
CREATE TRIGGER update_ranks
  AFTER INSERT OR UPDATE ON leaderboard
  FOR EACH STATEMENT
  EXECUTE FUNCTION update_leaderboard_ranks();

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, display_name, available_minutes)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', 'Jogador'),
    120
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();