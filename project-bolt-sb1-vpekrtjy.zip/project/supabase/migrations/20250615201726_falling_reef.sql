/*
  # Schema completo do EXPIRE - Plataforma de jogos baseada em tempo

  1. Tabelas Principais
    - `profiles` - Perfis dos usuários com minutos disponíveis
    - `games` - Catálogo de jogos disponíveis
    - `game_scores` - Pontuações dos jogadores
    - `game_sessions` - Sessões de jogo
    - `leaderboard` - Classificação global
    - `achievements` - Sistema de conquistas
    - `user_achievements` - Progresso das conquistas dos usuários

  2. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas específicas para cada operação
    - Triggers para atualizações automáticas

  3. Funcionalidades
    - Sistema de tempo automático
    - Ranking em tempo real
    - Conquistas progressivas
    - Histórico completo de jogos
*/

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop existing tables if they exist (for clean setup)
DROP TABLE IF EXISTS user_achievements CASCADE;
DROP TABLE IF EXISTS achievements CASCADE;
DROP TABLE IF EXISTS leaderboard CASCADE;
DROP TABLE IF EXISTS game_sessions CASCADE;
DROP TABLE IF EXISTS game_scores CASCADE;
DROP TABLE IF EXISTS games CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  available_minutes integer DEFAULT 120 NOT NULL,
  total_score integer DEFAULT 0 NOT NULL,
  games_played integer DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create games table
CREATE TABLE games (
  id serial PRIMARY KEY,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  image_url text,
  category text NOT NULL DEFAULT 'slots',
  provider text DEFAULT 'EXPIRE Games',
  rtp decimal(5,2) DEFAULT 96.5,
  volatility text DEFAULT 'medium' CHECK (volatility IN ('low', 'medium', 'high')),
  min_bet integer DEFAULT 1,
  max_bet integer DEFAULT 1000,
  minutes_cost integer DEFAULT 5 NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create game_scores table
CREATE TABLE game_scores (
  id serial PRIMARY KEY,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  game_id integer REFERENCES games(id) ON DELETE CASCADE NOT NULL,
  score integer NOT NULL DEFAULT 0,
  minutes_spent integer NOT NULL DEFAULT 0,
  session_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create game_sessions table
CREATE TABLE game_sessions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  game_type text NOT NULL,
  start_time timestamptz DEFAULT now() NOT NULL,
  end_time timestamptz,
  minutes_spent integer DEFAULT 0,
  score_earned integer DEFAULT 0,
  session_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create leaderboard table
CREATE TABLE leaderboard (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  username text NOT NULL,
  total_score integer NOT NULL DEFAULT 0,
  games_played integer NOT NULL DEFAULT 0,
  rank integer,
  updated_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id)
);

-- Create achievements table
CREATE TABLE achievements (
  id serial PRIMARY KEY,
  title text NOT NULL,
  description text NOT NULL,
  icon text DEFAULT '🏆',
  rarity text DEFAULT 'common' CHECK (rarity IN ('common', 'rare', 'epic', 'legendary')),
  points integer DEFAULT 100 NOT NULL,
  condition_type text NOT NULL, -- 'games_played', 'total_score', 'consecutive_wins', etc.
  condition_value integer NOT NULL,
  is_active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create user_achievements table
CREATE TABLE user_achievements (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  achievement_id integer REFERENCES achievements(id) ON DELETE CASCADE NOT NULL,
  progress integer DEFAULT 0 NOT NULL,
  is_unlocked boolean DEFAULT false NOT NULL,
  unlocked_at timestamptz,
  created_at timestamptz DEFAULT now() NOT NULL,
  UNIQUE(user_id, achievement_id)
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE leaderboard ENABLE ROW LEVEL SECURITY;
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id);

-- RLS Policies for games (public read)
CREATE POLICY "Anyone can view games" ON games
  FOR SELECT TO authenticated
  USING (is_active = true);

-- RLS Policies for game_scores
CREATE POLICY "Users can view own scores" ON game_scores
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own scores" ON game_scores
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

-- RLS Policies for game_sessions
CREATE POLICY "Users can view own sessions" ON game_sessions
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own sessions" ON game_sessions
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own sessions" ON game_sessions
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- RLS Policies for leaderboard (public read)
CREATE POLICY "Anyone can view leaderboard" ON leaderboard
  FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "System can manage leaderboard" ON leaderboard
  FOR ALL TO authenticated
  USING (true);

-- RLS Policies for achievements (public read)
CREATE POLICY "Anyone can view achievements" ON achievements
  FOR SELECT TO authenticated
  USING (is_active = true);

-- RLS Policies for user_achievements
CREATE POLICY "Users can view own achievements" ON user_achievements
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own achievements" ON user_achievements
  FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own achievements" ON user_achievements
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- Create indexes for better performance
CREATE INDEX idx_profiles_available_minutes ON profiles(available_minutes);
CREATE INDEX idx_profiles_total_score ON profiles(total_score);
CREATE INDEX idx_game_scores_user_id ON game_scores(user_id);
CREATE INDEX idx_game_scores_game_id ON game_scores(game_id);
CREATE INDEX idx_game_scores_score ON game_scores(score DESC);
CREATE INDEX idx_game_sessions_user_id ON game_sessions(user_id);
CREATE INDEX idx_leaderboard_rank ON leaderboard(rank);
CREATE INDEX idx_leaderboard_total_score ON leaderboard(total_score DESC);
CREATE INDEX idx_user_achievements_user_id ON user_achievements(user_id);
CREATE INDEX idx_user_achievements_unlocked ON user_achievements(is_unlocked);

-- Insert default games
INSERT INTO games (name, slug, description, category, provider, rtp, volatility, minutes_cost) VALUES
('Fortune Tiger', 'fortune-tiger', 'Junte-se ao poderoso tigre em uma jornada para a riqueza neste jogo de caça-níqueis com tema asiático.', 'slots', 'PG Soft', 96.8, 'high', 5),
('Crash', 'crash', 'Veja o multiplicador subir e saque antes que ele caia neste emocionante jogo de risco e recompensa.', 'crash', 'EXPIRE Games', 97.3, 'high', 3),
('Roleta Europeia', 'roulette', 'Experimente o clássico jogo de cassino com múltiplas opções de apostas e estratégias.', 'table', 'EXPIRE Games', 97.3, 'medium', 4),
('Sweet Bonanza', 'sweet-bonanza', 'Delicie-se neste caça-níqueis com tema de doces, com vitórias em cascata e giros grátis multiplicadores.', 'slots', 'Pragmatic Play', 96.5, 'high', 5),
('Mines', 'mines', 'Limpe o campo sem atingir nenhuma mina neste emocionante jogo de sorte.', 'dice', 'EXPIRE Games', 97.0, 'high', 4),
('Blackjack', 'blackjack', 'Vença o dealer com uma mão melhor neste clássico jogo de cartas de habilidade e sorte.', 'card', 'EXPIRE Games', 99.5, 'low', 6);

-- Insert default achievements
INSERT INTO achievements (title, description, icon, rarity, points, condition_type, condition_value) VALUES
('Primeiro Passo', 'Jogue seu primeiro jogo', '🎯', 'common', 50, 'games_played', 1),
('Viciado em Jogos', 'Jogue 10 jogos diferentes', '🎮', 'rare', 200, 'games_played', 10),
('Pontuação Alta', 'Alcance 1000 pontos em um único jogo', '⭐', 'epic', 500, 'single_score', 1000),
('Mestre dos Slots', 'Jogue slots 50 vezes', '👑', 'legendary', 1000, 'category_plays', 50),
('Crash Survivor', 'Saque antes do crash 25 vezes', '🚀', 'epic', 300, 'crash_wins', 25),
('Jogador Dedicado', 'Jogue por 7 dias consecutivos', '📅', 'rare', 400, 'consecutive_days', 7),
('Milionário', 'Acumule 10.000 pontos totais', '💰', 'legendary', 2000, 'total_score', 10000),
('Speedrunner', 'Complete 5 jogos em menos de 1 hora', '⚡', 'epic', 600, 'speed_games', 5);

-- Function to update leaderboard
CREATE OR REPLACE FUNCTION update_leaderboard()
RETURNS TRIGGER AS $$
BEGIN
  -- Update or insert leaderboard entry
  INSERT INTO leaderboard (user_id, username, total_score, games_played)
  SELECT 
    p.id,
    COALESCE(p.display_name, 'Jogador'),
    p.total_score,
    p.games_played
  FROM profiles p
  WHERE p.id = NEW.user_id
  ON CONFLICT (user_id) DO UPDATE SET
    username = COALESCE(EXCLUDED.username, leaderboard.username),
    total_score = EXCLUDED.total_score,
    games_played = EXCLUDED.games_played,
    updated_at = now();

  -- Update ranks
  WITH ranked_users AS (
    SELECT user_id, ROW_NUMBER() OVER (ORDER BY total_score DESC, games_played ASC) as new_rank
    FROM leaderboard
  )
  UPDATE leaderboard 
  SET rank = ranked_users.new_rank
  FROM ranked_users
  WHERE leaderboard.user_id = ranked_users.user_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to check and unlock achievements
CREATE OR REPLACE FUNCTION check_achievements()
RETURNS TRIGGER AS $$
DECLARE
  achievement_record RECORD;
  user_progress INTEGER;
BEGIN
  -- Check all achievements for the user
  FOR achievement_record IN 
    SELECT a.* FROM achievements a
    WHERE a.is_active = true
  LOOP
    -- Calculate progress based on condition type
    CASE achievement_record.condition_type
      WHEN 'games_played' THEN
        SELECT games_played INTO user_progress
        FROM profiles WHERE id = NEW.user_id;
        
      WHEN 'total_score' THEN
        SELECT total_score INTO user_progress
        FROM profiles WHERE id = NEW.user_id;
        
      WHEN 'single_score' THEN
        user_progress := NEW.score;
        
      ELSE
        user_progress := 0;
    END CASE;

    -- Insert or update user achievement progress
    INSERT INTO user_achievements (user_id, achievement_id, progress, is_unlocked, unlocked_at)
    VALUES (
      NEW.user_id, 
      achievement_record.id, 
      user_progress,
      user_progress >= achievement_record.condition_value,
      CASE WHEN user_progress >= achievement_record.condition_value THEN now() ELSE NULL END
    )
    ON CONFLICT (user_id, achievement_id) DO UPDATE SET
      progress = GREATEST(user_achievements.progress, user_progress),
      is_unlocked = user_progress >= achievement_record.condition_value,
      unlocked_at = CASE 
        WHEN user_progress >= achievement_record.condition_value AND user_achievements.unlocked_at IS NULL 
        THEN now() 
        ELSE user_achievements.unlocked_at 
      END;
  END LOOP;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to add minutes every hour
CREATE OR REPLACE FUNCTION add_hourly_minutes()
RETURNS void AS $$
BEGIN
  UPDATE profiles 
  SET 
    available_minutes = LEAST(available_minutes + 10, 480),
    updated_at = now()
  WHERE available_minutes < 480;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update profile stats when score is added
CREATE OR REPLACE FUNCTION update_profile_stats()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE profiles 
  SET 
    total_score = total_score + NEW.score,
    games_played = games_played + 1,
    updated_at = now()
  WHERE id = NEW.user_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER trigger_update_profile_stats
  AFTER INSERT ON game_scores
  FOR EACH ROW
  EXECUTE FUNCTION update_profile_stats();

CREATE TRIGGER trigger_update_leaderboard
  AFTER UPDATE OF total_score ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_leaderboard();

CREATE TRIGGER trigger_check_achievements
  AFTER INSERT ON game_scores
  FOR EACH ROW
  EXECUTE FUNCTION check_achievements();

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, display_name, available_minutes)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', 'Jogador'),
    120
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for new user registration
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();