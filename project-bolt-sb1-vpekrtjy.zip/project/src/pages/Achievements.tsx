import React, { useEffect, useState } from 'react'
import { Trophy, Star, Target, Zap, Award, Lock } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import { AchievementService } from '../services/achievementService'
import { UserAchievement } from '../lib/supabase'

const Achievements: React.FC = () => {
  const { currentUser } = useAuth()
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([])
  const [filter, setFilter] = useState<'all' | 'unlocked' | 'locked'>('all')
  const [loading, setLoading] = useState(true)
  const [progress, setProgress] = useState({ total: 0, unlocked: 0, percentage: 0 })

  useEffect(() => {
    if (currentUser) {
      loadAchievements()
    }
  }, [currentUser])

  const loadAchievements = async () => {
    if (!currentUser) return

    try {
      const [achievements, progressData] = await Promise.all([
        AchievementService.getUserAchievements(currentUser.id),
        AchievementService.getUserAchievementProgress(currentUser.id)
      ])
      
      setUserAchievements(achievements)
      setProgress(progressData)
    } catch (error) {
      console.error('Error loading achievements:', error)
    } finally {
      setLoading(false)
    }
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common':
        return 'border-gray-300 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
      case 'rare':
        return 'border-blue-300 bg-blue-50 dark:border-blue-600 dark:bg-blue-900'
      case 'epic':
        return 'border-purple-300 bg-purple-50 dark:border-purple-600 dark:bg-purple-900'
      case 'legendary':
        return 'border-yellow-300 bg-yellow-50 dark:border-yellow-600 dark:bg-yellow-900'
      default:
        return 'border-gray-300 bg-gray-50 dark:border-gray-600 dark:bg-gray-700'
    }
  }

  const getRarityTextColor = (rarity: string) => {
    switch (rarity) {
      case 'common':
        return 'text-gray-600 dark:text-gray-400'
      case 'rare':
        return 'text-blue-600 dark:text-blue-400'
      case 'epic':
        return 'text-purple-600 dark:text-purple-400'
      case 'legendary':
        return 'text-yellow-600 dark:text-yellow-400'
      default:
        return 'text-gray-600 dark:text-gray-400'
    }
  }

  const getIcon = (iconString: string) => {
    const iconMap: {[key: string]: React.ReactNode} = {
      '🎯': <Target className="w-6 h-6" />,
      '🎮': <Star className="w-6 h-6" />,
      '⭐': <Zap className="w-6 h-6" />,
      '👑': <Trophy className="w-6 h-6" />,
      '🚀': <Award className="w-6 h-6" />,
      '📅': <Star className="w-6 h-6" />,
      '💰': <Trophy className="w-6 h-6" />,
      '⚡': <Zap className="w-6 h-6" />
    }
    return iconMap[iconString] || <Trophy className="w-6 h-6" />
  }

  const filteredAchievements = userAchievements.filter(achievement => {
    if (filter === 'unlocked') return achievement.is_unlocked
    if (filter === 'locked') return !achievement.is_unlocked
    return true
  })

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Carregando conquistas...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8 transition-colors duration-200">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 text-gray-900 dark:text-white">🏆 Conquistas</h1>
          <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-6">
            Desbloqueie conquistas jogando e dominando diferentes jogos na plataforma EXPIRE.
          </p>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 max-w-md mx-auto">
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-semibold text-gray-900 dark:text-white">Progresso Geral</span>
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                {progress.unlocked}/{progress.total}
              </span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress.percentage}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              {progress.percentage}% completo
            </p>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center gap-4 mb-8">
          <button
            onClick={() => setFilter('all')}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              filter === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            Todas ({progress.total})
          </button>
          <button
            onClick={() => setFilter('unlocked')}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              filter === 'unlocked'
                ? 'bg-green-600 text-white'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            Desbloqueadas ({progress.unlocked})
          </button>
          <button
            onClick={() => setFilter('locked')}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              filter === 'locked'
                ? 'bg-gray-600 text-white'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
            }`}
          >
            Bloqueadas ({progress.total - progress.unlocked})
          </button>
        </div>

        {/* Achievements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAchievements.map((userAchievement) => {
            const achievement = userAchievement.achievement
            if (!achievement) return null

            return (
              <div
                key={userAchievement.id}
                className={`rounded-lg border-2 p-6 transition-all duration-300 hover:shadow-lg ${
                  userAchievement.is_unlocked
                    ? getRarityColor(achievement.rarity)
                    : 'border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 opacity-75'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-full ${
                    userAchievement.is_unlocked
                      ? getRarityColor(achievement.rarity)
                      : 'bg-gray-200 dark:bg-gray-700'
                  }`}>
                    {userAchievement.is_unlocked ? (
                      <div className={getRarityTextColor(achievement.rarity)}>
                        {getIcon(achievement.icon)}
                      </div>
                    ) : (
                      <Lock className="w-6 h-6 text-gray-400" />
                    )}
                  </div>
                  
                  <div className="text-right">
                    <span className={`text-xs font-bold uppercase px-2 py-1 rounded ${
                      userAchievement.is_unlocked
                        ? `${getRarityTextColor(achievement.rarity)} bg-opacity-20`
                        : 'text-gray-400 bg-gray-200 dark:bg-gray-700'
                    }`}>
                      {achievement.rarity}
                    </span>
                  </div>
                </div>

                <h3 className={`text-xl font-bold mb-2 ${
                  userAchievement.is_unlocked ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'
                }`}>
                  {achievement.title}
                </h3>
                
                <p className={`text-sm mb-4 ${
                  userAchievement.is_unlocked ? 'text-gray-600 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'
                }`}>
                  {achievement.description}
                </p>

                {!userAchievement.is_unlocked && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500 dark:text-gray-400">Progresso</span>
                      <span className="font-medium text-gray-700 dark:text-gray-300">
                        {userAchievement.progress}/{achievement.condition_value}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min((userAchievement.progress / achievement.condition_value) * 100, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                {userAchievement.is_unlocked && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-green-600 dark:text-green-400 text-sm font-medium">
                      <Trophy className="w-4 h-4 mr-1" />
                      Desbloqueada!
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      +{achievement.points} pts
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {filteredAchievements.length === 0 && (
          <div className="text-center py-12">
            <Trophy className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400 text-lg">Nenhuma conquista encontrada.</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default Achievements