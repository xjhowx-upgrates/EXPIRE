import React, { createContext, useContext, useEffect, useState } from 'react'
import { useAuth } from '../hooks/useAuth'
import { ProfileService } from '../services/profileService'

interface TimeContextType {
  availableMinutes: number
  spendMinutes: (amount: number) => Promise<boolean>
  addMinutes: (amount: number) => Promise<void>
  refreshMinutes: () => Promise<void>
  loading: boolean
}

const TimeContext = createContext<TimeContextType | undefined>(undefined)

export const useTime = () => {
  const context = useContext(TimeContext)
  if (context === undefined) {
    throw new Error('useTime must be used within a TimeProvider')
  }
  return context
}

export const TimeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth()
  const [availableMinutes, setAvailableMinutes] = useState(120)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (currentUser) {
      loadUserMinutes()
      
      // Add minutes every hour
      const interval = setInterval(() => {
        addMinutes(10)
      }, 60 * 60 * 1000) // 1 hour

      return () => clearInterval(interval)
    } else {
      setLoading(false)
    }
  }, [currentUser])

  const loadUserMinutes = async () => {
    if (!currentUser) {
      setLoading(false)
      return
    }

    try {
      const profile = await ProfileService.getProfile(currentUser.id)
      if (profile) {
        setAvailableMinutes(profile.available_minutes)
      }
    } catch (error) {
      console.error('Error loading user minutes:', error)
      // Set default if error
      setAvailableMinutes(120)
    } finally {
      setLoading(false)
    }
  }

  const spendMinutes = async (amount: number): Promise<boolean> => {
    if (!currentUser) return false
    
    if (availableMinutes < amount) {
      return false
    }

    try {
      const success = await ProfileService.spendMinutes(currentUser.id, amount)
      if (success) {
        setAvailableMinutes(prev => prev - amount)
        return true
      }
      return false
    } catch (error) {
      console.error('Error spending minutes:', error)
      return false
    }
  }

  const addMinutes = async (amount: number): Promise<void> => {
    if (!currentUser) return

    try {
      await ProfileService.addMinutes(currentUser.id, amount)
      setAvailableMinutes(prev => Math.min(prev + amount, 480)) // Max 8 hours
    } catch (error) {
      console.error('Error adding minutes:', error)
    }
  }

  const refreshMinutes = async (): Promise<void> => {
    await loadUserMinutes()
  }

  return (
    <TimeContext.Provider value={{ 
      availableMinutes, 
      spendMinutes, 
      addMinutes, 
      refreshMinutes,
      loading 
    }}>
      {children}
    </TimeContext.Provider>
  )
}