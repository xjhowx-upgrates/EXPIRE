import { supabase } from '../lib/supabase'
import { Achievement, UserAchievement } from '../lib/supabase'

export class AchievementService {
  static async getAllAchievements(): Promise<Achievement[]> {
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .eq('is_active', true)
      .order('rarity', { ascending: true })

    if (error) throw error
    return data || []
  }

  static async getUserAchievements(userId: string): Promise<UserAchievement[]> {
    const { data, error } = await supabase
      .from('user_achievements')
      .select(`
        *,
        achievement:achievements(*)
      `)
      .eq('user_id', userId)

    if (error) throw error
    return data || []
  }

  static async getUserAchievementProgress(userId: string): Promise<{
    total: number
    unlocked: number
    percentage: number
  }> {
    const achievements = await this.getAllAchievements()
    const userAchievements = await this.getUserAchievements(userId)
    
    const total = achievements.length
    const unlocked = userAchievements.filter(ua => ua.is_unlocked).length
    const percentage = total > 0 ? Math.round((unlocked / total) * 100) : 0

    return { total, unlocked, percentage }
  }

  static async initializeUserAchievements(userId: string): Promise<void> {
    try {
      const achievements = await this.getAllAchievements()
      
      const userAchievements = achievements.map(achievement => ({
        user_id: userId,
        achievement_id: achievement.id,
        progress: 0,
        is_unlocked: false
      }))

      const { error } = await supabase
        .from('user_achievements')
        .upsert(userAchievements, { onConflict: 'user_id,achievement_id' })

      if (error) throw error
    } catch (error) {
      console.error('Error initializing user achievements:', error)
    }
  }

  static async checkAndUpdateAchievements(userId: string): Promise<UserAchievement[]> {
    try {
      // This will be handled by database triggers, but we can also manually trigger it
      const { data, error } = await supabase.rpc('check_achievements', {
        p_user_id: userId
      })

      if (error) {
        console.warn('Manual achievement check failed:', error)
        return []
      }

      return await this.getUserAchievements(userId)
    } catch (error) {
      console.error('Error checking achievements:', error)
      return []
    }
  }

  static async getRecentUnlocks(userId: string, limit: number = 5): Promise<UserAchievement[]> {
    const { data, error } = await supabase
      .from('user_achievements')
      .select(`
        *,
        achievement:achievements(*)
      `)
      .eq('user_id', userId)
      .eq('is_unlocked', true)
      .order('unlocked_at', { ascending: false })
      .limit(limit)

    if (error) throw error
    return data || []
  }
}