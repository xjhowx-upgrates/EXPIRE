import { supabase } from '../lib/supabase'
import { Game, GameScore, GameSession } from '../lib/supabase'

export class GameService {
  static async getAllGames(): Promise<Game[]> {
    const { data, error } = await supabase
      .from('games')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })

    if (error) throw error
    return data || []
  }

  static async getGameBySlug(slug: string): Promise<Game | null> {
    const { data, error } = await supabase
      .from('games')
      .select('*')
      .eq('slug', slug)
      .eq('is_active', true)
      .single()

    if (error) throw error
    return data
  }

  static async getGameById(id: number): Promise<Game | null> {
    const { data, error } = await supabase
      .from('games')
      .select('*')
      .eq('id', id)
      .eq('is_active', true)
      .single()

    if (error) throw error
    return data
  }

  static async saveScore(gameId: number, score: number, minutesSpent: number): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    const { error } = await supabase
      .from('game_scores')
      .insert({
        user_id: user.id,
        game_id: gameId,
        score: score,
        minutes_spent: minutesSpent
      })

    if (error) throw error
  }

  static async getUserScores(userId: string, limit: number = 50): Promise<GameScore[]> {
    const { data, error } = await supabase
      .from('game_scores')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (error) throw error
    return data || []
  }

  static async getTopScores(gameId: number, limit: number = 10): Promise<any[]> {
    const { data, error } = await supabase
      .from('game_scores')
      .select(`
        *,
        profiles!inner(display_name)
      `)
      .eq('game_id', gameId)
      .order('score', { ascending: false })
      .limit(limit)

    if (error) throw error
    return data || []
  }

  static async createGameSession(gameType: string): Promise<string> {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    const { data, error } = await supabase
      .from('game_sessions')
      .insert({
        user_id: user.id,
        game_type: gameType,
      })
      .select()
      .single()

    if (error) throw error
    return data.id
  }

  static async endGameSession(sessionId: string, minutesSpent: number, scoreEarned: number): Promise<void> {
    const { error } = await supabase
      .from('game_sessions')
      .update({
        end_time: new Date().toISOString(),
        minutes_spent: minutesSpent,
        score_earned: scoreEarned,
      })
      .eq('id', sessionId)

    if (error) throw error
  }

  static async getGameStats(gameId: number): Promise<any> {
    const { data, error } = await supabase
      .from('game_scores')
      .select('score, created_at, user_id')
      .eq('game_id', gameId)

    if (error) throw error

    const scores = data || []
    const totalPlayers = new Set(scores.map(s => s.user_id)).size
    const averageScore = scores.length > 0 ? scores.reduce((sum, s) => sum + s.score, 0) / scores.length : 0
    const highestScore = scores.length > 0 ? Math.max(...scores.map(s => s.score)) : 0

    return {
      totalPlayers,
      averageScore: Math.round(averageScore),
      highestScore,
      totalGames: scores.length
    }
  }
}