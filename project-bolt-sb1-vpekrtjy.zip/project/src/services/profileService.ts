import { supabase } from '../lib/supabase'
import { Profile, LeaderboardEntry } from '../lib/supabase'

export class ProfileService {
  static async getProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()

    if (error) {
      if (error.code === 'PGRST116') {
        // Profile doesn't exist, create it
        return await this.createProfile(userId)
      }
      throw error
    }
    return data
  }

  static async createProfile(userId: string, displayName?: string): Promise<Profile> {
    const { data, error } = await supabase
      .from('profiles')
      .insert({
        id: userId,
        display_name: displayName || 'Jogador',
        available_minutes: 120,
        total_score: 0,
        games_played: 0
      })
      .select()
      .single()

    if (error) throw error
    return data
  }

  static async updateProfile(userId: string, updates: Partial<Profile>): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)

    if (error) throw error
  }

  static async getLeaderboard(limit: number = 50): Promise<LeaderboardEntry[]> {
    const { data, error } = await supabase
      .from('leaderboard')
      .select('*')
      .order('rank', { ascending: true })
      .limit(limit)

    if (error) throw error
    return data || []
  }

  static async getUserRank(userId: string): Promise<number | null> {
    const { data, error } = await supabase
      .from('leaderboard')
      .select('rank')
      .eq('user_id', userId)
      .single()

    if (error) return null
    return data?.rank || null
  }

  static async updateAvailableMinutes(userId: string, minutes: number): Promise<void> {
    const { error } = await supabase
      .from('profiles')
      .update({
        available_minutes: Math.max(0, Math.min(480, minutes)),
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)

    if (error) throw error
  }

  static async addMinutes(userId: string, minutesToAdd: number): Promise<void> {
    const { data: profile } = await supabase
      .from('profiles')
      .select('available_minutes')
      .eq('id', userId)
      .single()

    if (profile) {
      const newMinutes = Math.min(480, profile.available_minutes + minutesToAdd)
      await this.updateAvailableMinutes(userId, newMinutes)
    }
  }

  static async spendMinutes(userId: string, minutesToSpend: number): Promise<boolean> {
    const { data: profile } = await supabase
      .from('profiles')
      .select('available_minutes')
      .eq('id', userId)
      .single()

    if (!profile || profile.available_minutes < minutesToSpend) {
      return false
    }

    const newMinutes = profile.available_minutes - minutesToSpend
    await this.updateAvailableMinutes(userId, newMinutes)
    return true
  }
}